package com.example.procurementfactory.controller;

import com.example.procurementfactory.model.ProcurementRequest;
import com.example.procurementfactory.service.ApprovalService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
public class ApprovalController {
    private final ApprovalService service;

    public ApprovalController(ApprovalService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String index() {
        return "forward:/index.html";
    }

    @GetMapping("/api/requests/{role}")
    @ResponseBody
    public List<ProcurementRequest> getRequests(@PathVariable String role) {
        return service.getPendingRequestsByRole(role);
    }

    @PostMapping("/api/approve/{id}/{role}")
    @ResponseBody
    public ResponseEntity<?> approve(@PathVariable String id, @PathVariable String role) {
        boolean success = service.approveRequest(id, role);
        if (success) {
            ProcurementRequest req = service.getRequest(id);
            return ResponseEntity.ok(Map.of("success", true, "newStatus", req.getStatus().toString()));
        } else {
            return ResponseEntity.badRequest().body(Map.of("success", false));
        }
    }

    @PostMapping("/api/submit")
    @ResponseBody
    public ProcurementRequest submit(@RequestBody Map<String, Object> payload) {
        String desc = (String) payload.get("description");
        double amount = Double.parseDouble(payload.get("amount").toString());
        return service.submitRequest(desc, amount);
    }

    @GetMapping("/api/all")
    @ResponseBody
    public List<ProcurementRequest> allRequests() {
        return service.getAllRequests();
    }

    @GetMapping("/api/history/{id}")
    @ResponseBody
    public List<ProcurementRequest.ApprovalHistoryEntry> getHistory(@PathVariable String id) {
        ProcurementRequest req = service.getRequest(id);
        return req != null ? req.getApprovalHistory() : List.of();
    }
}