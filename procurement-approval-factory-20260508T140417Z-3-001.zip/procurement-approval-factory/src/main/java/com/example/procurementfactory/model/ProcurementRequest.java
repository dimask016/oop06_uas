package com.example.procurementfactory.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class ProcurementRequest {
    private String id;
    private String description;
    private double amount;
    private ApprovalStatus status;
    private List<ApprovalHistoryEntry> approvalHistory;

    public ProcurementRequest(String description, double amount) {
        this.id = UUID.randomUUID().toString().substring(0, 8);
        this.description = description;
        this.amount = amount;
        this.status = ApprovalStatus.WAITING_MANAGER;
        this.approvalHistory = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getDescription() { return description; }
    public double getAmount() { return amount; }
    public ApprovalStatus getStatus() { return status; }
    public void setStatus(ApprovalStatus status) { this.status = status; }
    public List<ApprovalHistoryEntry> getApprovalHistory() { return approvalHistory; }

    public void addHistory(String role, String remark) {
        approvalHistory.add(new ApprovalHistoryEntry(role, remark, new Date()));
    }

    public ApprovalStatus nextStatusAfter(ApprovalStatus current) {
        switch (current) {
            case WAITING_MANAGER:
                if (amount <= 50_000_000) return ApprovalStatus.APPROVED;
                else return ApprovalStatus.WAITING_DIVISION_HEAD;
            case WAITING_DIVISION_HEAD:
                if (amount <= 250_000_000) return ApprovalStatus.APPROVED;
                else return ApprovalStatus.WAITING_DIRECTOR;
            case WAITING_DIRECTOR:
                return ApprovalStatus.APPROVED;
            default:
                return ApprovalStatus.APPROVED;
        }
    }

    public static class ApprovalHistoryEntry {
        private String role;
        private String remark;
        private Date timestamp;

        public ApprovalHistoryEntry(String role, String remark, Date timestamp) {
            this.role = role;
            this.remark = remark;
            this.timestamp = timestamp;
        }

        public String getRole() { return role; }
        public String getRemark() { return remark; }
        public Date getTimestamp() { return timestamp; }
    }
}