package com.example.procurementfactory.service;

import com.example.procurementfactory.model.ProcurementRequest;
import com.example.procurementfactory.model.ApprovalStatus;
import com.example.procurementfactory.handler.ApprovalHandler;
import com.example.procurementfactory.handler.ApprovalHandlerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ApprovalService {
    private final Map<String, ProcurementRequest> requests = new HashMap<>();
    private final ApprovalHandler workflowEngine;

    public ApprovalService() {
        this.workflowEngine = ApprovalHandlerFactory.createWorkflow();

        // Sample data (optional)
        submitRequest("Laptop kantor", 45_000_000);
        submitRequest("Software ERP", 150_000_000);
        submitRequest("Renovasi gedung", 800_000_000);
        submitRequest("Alat tulis", 5_000_000);
        submitRequest("Server baru", 120_000_000);
        submitRequest("Kendaraan operasional", 300_000_000);
    }

    public ProcurementRequest submitRequest(String description, double amount) {
        if (amount > 1_000_000_000) amount = 1_000_000_000; // batas maksimal 1M
        ProcurementRequest req = new ProcurementRequest(description, amount);
        requests.put(req.getId(), req);
        return req;
    }

    public List<ProcurementRequest> getPendingRequestsByRole(String role) {
        ApprovalStatus requiredStatus = mapRoleToStatus(role);
        if (requiredStatus == null) return Collections.emptyList();
        return requests.values().stream()
                .filter(r -> r.getStatus() == requiredStatus)
                .collect(Collectors.toList());
    }

    private ApprovalStatus mapRoleToStatus(String role) {
        switch (role.toUpperCase()) {
            case "MANAGER": return ApprovalStatus.WAITING_MANAGER;
            case "DIVISION_HEAD": return ApprovalStatus.WAITING_DIVISION_HEAD;
            case "DIRECTOR": return ApprovalStatus.WAITING_DIRECTOR;
            default: return null;
        }
    }

    public boolean approveRequest(String requestId, String role) {
        ProcurementRequest req = requests.get(requestId);
        if (req == null) return false;

        ApprovalStatus expected = mapRoleToStatus(role);
        if (req.getStatus() != expected) return false;

        workflowEngine.handle(req);
        return true;
    }

    public ProcurementRequest getRequest(String id) {
        return requests.get(id);
    }

    public List<ProcurementRequest> getAllRequests() {
        return new ArrayList<>(requests.values());
    }
}