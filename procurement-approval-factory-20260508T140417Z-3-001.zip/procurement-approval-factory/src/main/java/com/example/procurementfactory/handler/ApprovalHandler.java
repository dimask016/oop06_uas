package com.example.procurementfactory.handler;

import com.example.procurementfactory.model.ProcurementRequest;

public interface ApprovalHandler {
    void handle(ProcurementRequest request);
    void setNext(ApprovalHandler next);
}