package com.example.procurementfactory.model;

public enum ApprovalStatus {
    WAITING_MANAGER,
    WAITING_DIVISION_HEAD,
    WAITING_DIRECTOR,
    APPROVED
}