package com.example.procurementfactory.handler;

public class ApprovalHandlerFactory {

    public static ApprovalHandler createWorkflow() {
        ManagerHandler manager = new ManagerHandler();
        DivisionHeadHandler division = new DivisionHeadHandler();
        DirectorHandler director = new DirectorHandler();

        manager.setNext(division);
        division.setNext(director);

        return manager;
    }
}