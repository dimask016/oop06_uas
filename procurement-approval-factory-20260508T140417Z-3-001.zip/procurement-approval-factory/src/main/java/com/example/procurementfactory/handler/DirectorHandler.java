package com.example.procurementfactory.handler;

import com.example.procurementfactory.model.ProcurementRequest;
import com.example.procurementfactory.model.ApprovalStatus;

public class DirectorHandler implements ApprovalHandler {
    private ApprovalHandler next;

    @Override
    public void setNext(ApprovalHandler next) {
        this.next = next;
    }

    @Override
    public void handle(ProcurementRequest request) {
        if (request.getStatus() == ApprovalStatus.WAITING_DIRECTOR) {
            request.addHistory("DIRECTOR", "Direksi menyetujui (nominal: " + request.getAmount() + ")");
            System.out.println("✅ Direksi approve: " + request.getDescription());

            ApprovalStatus newStatus = request.nextStatusAfter(ApprovalStatus.WAITING_DIRECTOR);
            request.setStatus(newStatus);
        } else if (next != null) {
            next.handle(request);
        }
    }
}