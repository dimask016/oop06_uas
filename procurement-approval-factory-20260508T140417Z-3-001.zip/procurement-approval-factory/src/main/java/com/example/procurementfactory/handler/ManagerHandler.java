package com.example.procurementfactory.handler;

import com.example.procurementfactory.model.ProcurementRequest;
import com.example.procurementfactory.model.ApprovalStatus;

public class ManagerHandler implements ApprovalHandler {
    private ApprovalHandler next;

    @Override
    public void setNext(ApprovalHandler next) {
        this.next = next;
    }

    @Override
    public void handle(ProcurementRequest request) {
        if (request.getStatus() == ApprovalStatus.WAITING_MANAGER) {
            request.addHistory("MANAGER", "Manager menyetujui (nominal: " + request.getAmount() + ")");
            System.out.println("✅ Manager approve: " + request.getDescription());

            ApprovalStatus newStatus = request.nextStatusAfter(ApprovalStatus.WAITING_MANAGER);
            request.setStatus(newStatus);

            // Hentikan di sini, tidak lanjut otomatis ke level berikutnya
        } else if (next != null) {
            // Lewatkan ke handler berikutnya jika status tidak sesuai
            next.handle(request);
        }
    }
}