package com.example.procurementfactory.handler;

import com.example.procurementfactory.model.ProcurementRequest;
import com.example.procurementfactory.model.ApprovalStatus;

public class DivisionHeadHandler implements ApprovalHandler {
    private ApprovalHandler next;

    @Override
    public void setNext(ApprovalHandler next) {
        this.next = next;
    }

    @Override
    public void handle(ProcurementRequest request) {
        if (request.getStatus() == ApprovalStatus.WAITING_DIVISION_HEAD) {
            request.addHistory("DIVISION_HEAD", "Kepala Divisi menyetujui (nominal: " + request.getAmount() + ")");
            System.out.println("✅ Kepala Divisi approve: " + request.getDescription());

            ApprovalStatus newStatus = request.nextStatusAfter(ApprovalStatus.WAITING_DIVISION_HEAD);
            request.setStatus(newStatus);

            // Hentikan di sini
        } else if (next != null) {
            next.handle(request);
        }
    }
}