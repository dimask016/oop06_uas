// Helper format Rupiah
function formatRupiah(amount) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(amount);
}

// Format tanggal
function formatDate(dateArray) {
    if (!dateArray) return '';
    // dateArray dari java.util.Date: [tahun, bulan, tanggal, jam, menit, detik]
    const d = new Date(dateArray[0], dateArray[1]-1, dateArray[2], dateArray[3], dateArray[4], dateArray[5]);
    return d.toLocaleString('id-ID');
}

// Status label
function statusLabel(status) {
    const map = {
        'WAITING_MANAGER': 'Menunggu Manager',
        'WAITING_DIVISION_HEAD': 'Menunggu Kepala Divisi',
        'WAITING_DIRECTOR': 'Menunggu Direksi',
        'APPROVED': '✅ Disetujui'
    };
    return map[status] || status;
}

// Submit pengajuan baru
document.getElementById('submitBtn')?.addEventListener('click', async () => {
    const desc = document.getElementById('descInput').value;
    const amount = parseFloat(document.getElementById('amountInput').value);
    if (!desc || isNaN(amount) || amount <= 0) {
        document.getElementById('submitMessage').innerHTML = '<span style="color:red">Isi deskripsi dan nominal valid (1 - 1.000.000.000)</span>';
        return;
    }
    if (amount > 1_000_000_000) {
        document.getElementById('submitMessage').innerHTML = '<span style="color:red">Nominal maksimal 1 Milyar!</span>';
        return;
    }
    try {
        const res = await fetch('/api/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ description: desc, amount: amount })
        });
        const data = await res.json();
        document.getElementById('submitMessage').innerHTML = `<span style="color:green">✅ Pengajuan ${data.id} berhasil dibuat!</span>`;
        document.getElementById('descInput').value = '';
        document.getElementById('amountInput').value = '';
        // refresh semua
        document.getElementById('showAllBtn')?.click();
        document.getElementById('loadBtn')?.click();
    } catch (err) {
        document.getElementById('submitMessage').innerHTML = '<span style="color:red">Gagal submit</span>';
    }
});

// Load pending request sesuai role
document.getElementById('loadBtn')?.addEventListener('click', async () => {
    const role = document.getElementById('roleSelect').value;
    const container = document.getElementById('requestsContainer');
    container.innerHTML = '<p>Loading...</p>';
    try {
        const res = await fetch(`/api/requests/${role}`);
        const requests = await res.json();
        if (!requests.length) {
            container.innerHTML = '<p class="info">✅ Tidak ada pengajuan pending untuk role ini.</p>';
            return;
        }
        let html = '表格<table>①<th>ID</th><th>Deskripsi</th><th>Nilai</th><th>Status Saat Ini</th><th>Aksi</th></tr>';
        for (const req of requests) {
            html += `
                <tr>
                    <td>${req.id}</td>
                    <td>${req.description}</td>
                    <td>${formatRupiah(req.amount)}</td>
                    <td>${statusLabel(req.status)}</td>
                    <td><button class="approve-btn" data-id="${req.id}" data-role="${role}">Approve</button></td>
                </tr>
            `;
        }
        html += '</table>';
        container.innerHTML = html;

        // Attach approve events
        document.querySelectorAll('.approve-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = btn.getAttribute('data-id');
                const role = btn.getAttribute('data-role');
                try {
                    const res = await fetch(`/api/approve/${id}/${role}`, { method: 'POST' });
                    const result = await res.json();
                    if (result.success) {
                        alert(`✅ Pengajuan ${id} berhasil di-approve. Status sekarang: ${result.newStatus}`);
                        document.getElementById('loadBtn').click();
                        document.getElementById('showAllBtn').click();
                    } else {
                        alert('❌ Gagal approve. Pastikan role sesuai tahap workflow.');
                    }
                } catch (err) {
                    alert('Error saat approve');
                }
            });
        });
    } catch (err) {
        container.innerHTML = '<p class="error">Error memuat data.</p>';
        console.error(err);
    }
});

// Tampilkan semua request + history
document.getElementById('showAllBtn')?.addEventListener('click', async () => {
    const container = document.getElementById('allRequestsContainer');
    container.innerHTML = 'Loading...';
    try {
        const res = await fetch('/api/all');
        const all = await res.json();
        if (!all.length) {
            container.innerHTML = '<p>Tidak ada data.</p>';
            return;
        }
        let html = '<table><thead><tr><th>ID</th><th>Deskripsi</th><th>Nilai</th><th>Status</th><th>Riwayat Approval</th></tr></thead><tbody>';
        for (const req of all) {
            // fetch history per request
            const historyRes = await fetch(`/api/history/${req.id}`);
            const history = await historyRes.json();
            let historyHtml = '<ul class="history-list">';
            if (history.length === 0) historyHtml += '<li>Belum ada approval</li>';
            history.forEach(h => {
                historyHtml += `<li><strong>${h.role}</strong>: ${h.remark}<br><small>${formatDate(h.timestamp)}</small></li>`;
            });
            historyHtml += '</ul>';
            html += `
                <tr>
                    <td>${req.id}</td>
                    <td>${req.description}</td>
                    <td>${formatRupiah(req.amount)}</td>
                    <td>${statusLabel(req.status)}</td>
                    <td>${historyHtml}</td>
                </tr>
            `;
        }
        html += '</tbody></table>';
        container.innerHTML = html;
    } catch (err) {
        container.innerHTML = '<p>Gagal load data.</p>';
        console.error(err);
    }
});

// Auto load saat pertama
window.onload = () => {
    document.getElementById('showAllBtn')?.click();
};